const express = require('express');
const { MongoClient } = require('mongodb');
const app = express();
const path = require('path');

// Permite servir arquivos estáticos da pasta public
app.use(express.static('./public'));

// Substitua aqui pela sua string de conexão do MongoDB Atlas
const uri = "mongodb+srv://pedrocembrone_db_user:<db_password>@cluster0.mw6he1i.mongodb.net/?appName=Cluster0";
const client = new MongoClient(uri);

async function main() {
    try {
        await client.connect();
        console.log("MongoDB conectado!");

        const db = client.db("meubanco");
        const itensCollection = db.collection("itens");

        // Rota para cadastrar item via formulário
        app.get('/cadastra_item', async (req, res) => {
            const item = {
                nome: req.query.Nome,
                tipo: parseInt(req.query.Tipo),
                quantidade: parseInt(req.query.Quantidade),
                data: req.query.Data
            };
            await itensCollection.insertOne(item);
            res.redirect('/'); // volta para a página principal
        });

        // Rota para retornar todos os itens em JSON
        app.get('/itens', async (req, res) => {
            const itens = await itensCollection.find().toArray();
            res.json(itens);
        });

        // Rodar servidor na porta 3000
        app.listen(3000, () => {
            console.log("Servidor rodando na porta 3000");
        });

    } catch (err) {
        console.error(err);
    }
}

main();

